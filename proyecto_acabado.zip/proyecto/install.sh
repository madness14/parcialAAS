#!/bin/bash
apt-get update
apt-get install -y ansible sshpass vagrant 

